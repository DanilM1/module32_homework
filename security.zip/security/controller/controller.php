<?php

error_reporting(0);

include './model/PDO.php';

$info = ['|*&^end$$$|', '|##@@$$**&&^^|'];
$address = './model/users.txt';

if ($_POST['exit']) {
    session_destroy();
    setcookie('user', null, -1, '/');
    include './view/security.php';
}
else {
    if ($_COOKIE['user']) {
        $a[0] = $_COOKIE['user'];
        include './model/security.php';
        if ($answer) {
            include './view/content.php';
            $a[1] = $a[0];
            $a[1] = password_hash($a[1].$info[1], PASSWORD_ARGON2I);
            $a[1] = substr($a[1], 50, 90);
            include './model/change_security.php';
            $_COOKIE['user']  = $a[1];
        }
        else
            include './view/security.php';
    }
    else {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $file = file_get_contents($address);
            if ($_POST['logIn']) {
                $a[0] = crypt($_POST['logIn'], $info[0]);
                $a[1] = crypt($_POST['password'], $info[1]);
                if (strpos($file, $a[0]) !== false) {
                    $a[2] = strpos($file, $a[0]);
                    $a[2] = substr($file, $a[2], stripos($file, $info[0], $a[2]));
                    $a[2] = explode($info[1], $a[2]);
                    if ($a[2][0] === $a[0] && $a[2][1] === $a[1]) {
                        echo '<script type="text/javascript"> alert("Вход выполнен"); </script>';
                        $a[1] = password_hash($a[1].$info[1], PASSWORD_ARGON2I);
                        $a[1] = substr($a[1], 50, 90);
                        include './model/change_security_start.php';
                        if ($_POST['remember_me']) 
                            setcookie('user', $a[1], time() + 300);
                        else {
                            session_start();
                            $_SESSION['user'] = $a[1];
                        }
                        header("Refresh:0");
                    }
                    else {
                        echo '<script type="text/javascript"> alert("Что-то не так с логином и/или паролем"); </script>';
                        include './view/security.php';
                        error_log("Пользователь ".$_POST['logIn']." забыл свой пароль.".PHP_EOL, 3, "errors.log");
                    }
                }
                else {
                    echo '<script type="text/javascript"> alert("Что-то не так с логином и/или паролем"); </script>';
                    include './view/security.php';
                }
            }
            else {
                $a[0] = crypt($_POST['register'], $info[0]);
                if (strpos($file, $a[0]) !== false)
                    echo '<script type="text/javascript"> alert("Логин занят другим пользователем"); </script>';
                else {
                    echo '<script type="text/javascript"> alert("Регистрация прошла успешно"); </script>';
                    $a[1] = crypt($_POST['password'], $info[1]);
                    file_put_contents($address, $a[0].$info[1].$a[1].$info[1].$info[0].PHP_EOL, FILE_APPEND);
                    include './model/add_user.php';
                }
                include './view/security.php';
            }
        }
        else {
            session_start();
            if ($_SESSION['user']) {
                $a[0] = $_SESSION['user'];
                include './model/security.php';
                if ($answer) {
                    include './view/content.php';
                    $a[1] = $a[0];
                    $a[1] = password_hash($a[1].$info[1], PASSWORD_ARGON2I);
                    $a[1] = substr($a[1], 50, 90);
                    include './model/change_security.php';
                    $_SESSION['user'] = $a[1];
                }
                else
                    include './view/security.php';
            }
            else
                include './view/security.php';
        }
    
        if ($answer['options'] === 'admin') include './view/role_options.php';
    }
}

?>
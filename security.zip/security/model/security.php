<?php
    $sql = 'SELECT options FROM users WHERE security = ?';
    $sth = $dbh->prepare($sql);
    $sth->execute(array($a[0]));
    $answer = $sth->fetch(PDO::FETCH_ASSOC);
    if (!$answer) error_log("Новая сессия.".PHP_EOL, 3, "errors.log");
?>
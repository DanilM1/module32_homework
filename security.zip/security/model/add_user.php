<?php
    $sql = 'INSERT INTO users (user, options, security) VALUES (:user, :options, :security)';
    $sth = $dbh->prepare($sql);
    $a[1] = 'admin';
    $sth->bindValue(':user', $a[0]);
    $sth->bindValue(':options', $a[1]);
    $sth->bindValue(':security', $a[1]);
    $sth->execute();
    if (!$sth) error_log("Не добавлен пользователь ".$a[0].PHP_EOL, 3, "errors.log");
?>
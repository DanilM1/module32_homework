<?php
    $sql = 'UPDATE users SET security = :security WHERE user = :user';
    $sth = $dbh->prepare($sql);
    $sth->bindValue(':security', $a[1]);
    $sth->bindValue(':user', $a[0]);
    $sth->execute();
    if (!$sth) error_log("Безопасное обновление данных на старте не сработало.".PHP_EOL, 3, "errors.log");
?>
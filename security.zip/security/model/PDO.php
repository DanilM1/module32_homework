<?php
    $dbh = new PDO('mysql:host=' . 'localhost'. ';dbname=' . 'security', 'root', '');
    if (!$dbh) error_log("Нет соединения с БД.".PHP_EOL, 3, "errors.log");
?>
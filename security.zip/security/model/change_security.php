<?php
    $sql = 'UPDATE users SET security = :security WHERE security = :old';
    $sth = $dbh->prepare($sql);
    $sth->bindValue(':security', $a[1]);
    $sth->bindValue(':old', $a[0]);
    $sth->execute();
    if (!$sth) error_log("Безопасное обновление данных во время работы не сработало.".PHP_EOL, 3, "errors.log");
?>
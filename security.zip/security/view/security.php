<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="./view/styles.css">
    <title>Security</title>
</head>
<body>
    <ul>
        <li><a id="logIn" href="#">Log In</a></li>
        <li><a id="register" href="#">Register</a></li>
    </ul>
    <hr>
    <h1 id="security"></h1>
    <form id="form" method="post">
        <label for="name">Name:</label><br>
        <input type="text" id="name"><br><br>
        <label for="password">Password:</label><br>
        <input type="text" id="password" name="password"><br><br>
        <input type="checkbox" id="remember_me" name="remember_me" class="checkbox">
        <label for="remember_me" class="checkbox">Remember me</label><br><br>
        <input type="submit" value="Submit">
    </form>
    <script src="./view/security.js"></script>
</body>
</html>
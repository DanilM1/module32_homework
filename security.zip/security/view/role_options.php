<script>
        document.getElementById('button').disabled = false;
</script>
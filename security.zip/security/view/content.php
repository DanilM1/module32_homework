<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Content</title>
</head>
<body>
    <form method="post">
        <input type="submit" name="exit" value="Exit">
    </form>
    <br>
        <img src="./view/Koala.jpg" width="25%" alt="image">
    <br><br>
    <button id="button" disabled>Close</button>
</body>
</html>
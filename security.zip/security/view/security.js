let

content = ['logIn', 'register', 'security', 'form', 'name', 'checkbox'],

color = ['blue', 'red'],

logIn = document.getElementById(content[0]),
register = document.getElementById(content[1]),
security = document.getElementById(content[2]),
form = document.getElementById(content[3]),
name_ = document.getElementById(content[4]),
checkbox = document.getElementsByClassName(content[5]);

logIn.addEventListener('click', function() {
    logIn.style.color = color[1];
    register.style.color = color[0];
    security.innerHTML  = content[0].toUpperCase();
    form.style.display = 'block';
    checkbox[0].style.display = 'inline';
    checkbox[0].name = 'remember_me';
    checkbox[1].style.display = 'inline';
    name_.name = content[0];
});

register.addEventListener('click', function() {
    logIn.style.color = color[0];
    register.style.color = color[1];
    security.innerHTML  = content[1].toUpperCase();
    form.style.display = 'block';
    checkbox[0].style.display = 'none';
    checkbox[0].name = ' ';
    checkbox[1].style.display = 'none';
    name_.name = content[1];
});